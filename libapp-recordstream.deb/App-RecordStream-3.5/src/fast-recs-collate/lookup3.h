
#include <stdint.h>     /* defines uint32_t etc */

extern uint32_t hashlittle( const void *key, size_t length, uint32_t initval);

