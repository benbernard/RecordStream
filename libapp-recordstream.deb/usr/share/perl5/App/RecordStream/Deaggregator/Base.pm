package App::RecordStream::Deaggregator::Base;

# marker only

1;
