package App::RecordStream::Aggregator::Aggregation;

sub returns_record
{
   return 0;
}

1;
