package App::RecordStream::Aggregator::Aggregation;

our $VERSION = "3.4";

sub returns_record
{
   return 0;
}

1;
