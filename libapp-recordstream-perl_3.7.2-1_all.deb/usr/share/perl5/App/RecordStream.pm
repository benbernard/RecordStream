package App::RecordStream;

=head1 NAME

App::RecordStream

=head1 AUTHOR

Benjamin Bernard <perlhacker@benjaminbernard.com>
Keith Amling <keith.amling@gmail.com>

=head1 DESCRIPTION

Dummy class for easier CPAN install

=head1 SYNOPSIS

Please ignore this version.

See doc/aRecordStreamStory or INSTALLING for more information on getting
started with RecordStream

=cut

our $VERSION = "3.4";

use strict;
use warnings;

1;
