package App::RecordStream::Aggregator::Aggregation;

our $VERSION = "3.4";

# marker for aggregators (used in isa checks)

1;
