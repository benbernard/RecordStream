package App::RecordStream::Clumper::Base;

# marker only

1;
